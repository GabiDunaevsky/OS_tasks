208588392_208407379

src:
https://developpaper.com/using-mmap-to-copy-large-files-single-process-and-multi-process/
https://beej.us/guide/bgipc/html/multi/unixsock.html
https://www.informit.com/articles/article.aspx?p=23618&seqNum=4
https://riptutorial.com/posix/example/15910/simple-mutex-usage
https://hpc-tutorials.llnl.gov/posix/example_using_cond_vars/
https://www.ibm.com/docs/en/zos/2.1.0?topic=functions-pthread-mutex-lock-wait-lock-mutex-object
https://linuxhint.com/pthread-cond-wait-function-c/
https://www.cs.cmu.edu/afs/cs/academic/class/15492-f07/www/pthreads.html
https://hpc-tutorials.llnl.gov/posix/example_using_cond_vars/
https://docs.oracle.com/cd/E19455-01/806-5257/6je9h032r/index.html
https://stackoverflow.com/questions/8832577/pthread-mutex-two-threads-interchangebly-locks-unlocks-is-it-valid-approach


